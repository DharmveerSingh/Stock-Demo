# Stocks
Stocks Demo app


This is a sample app for stock view and purchase demo real time.

Technologies:
1. Java8
2. Spring Boot
3. Spring Webflux
4. Sping MVC
5. Spring Schedular 
6. Apache Kafka
7. Java Script (UI)
8. Ajax (UI)
9. thymeleaf (UI)
10. Couchbase DB(Database)
