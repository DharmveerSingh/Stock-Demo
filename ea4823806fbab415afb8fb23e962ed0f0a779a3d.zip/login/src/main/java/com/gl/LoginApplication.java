package com.gl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author dharamveer.singh
 *
 */

@SpringBootApplication
public class LoginApplication{
    public static void main(String[] args) {
        SpringApplication.run(LoginApplication.class, args);
    }
}

